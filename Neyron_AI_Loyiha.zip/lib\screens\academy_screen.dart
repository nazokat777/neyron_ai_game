import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../theme/app_colors.dart';

/// "Akademiya" — reyting, duel, klub
class AcademyScreen extends StatelessWidget {
  const AcademyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(gradient: AppColors.cosmicGradient),
      child: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Akademiya',
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.w700,
                  color: AppColors.pureWhite,
                ),
              ).animate().fadeIn(),
              const SizedBox(height: 4),
              const Text(
                'Reyting, duellar va klub',
                style: TextStyle(color: AppColors.pureWhite, fontSize: 14),
              ),
              const SizedBox(height: 32),
              _featureCard(
                emoji: '🏆',
                title: 'Haftalik reyting',
                description: 'Shahar va yosh guruhi ichida joyingiz',
                accent: AppColors.plasmaYellow,
              ),
              const SizedBox(height: 12),
              _featureCard(
                emoji: '⚔️',
                title: 'Duel',
                description: 'Do\'st bilan real vaqtda musobaqa',
                accent: AppColors.accentRed,
              ),
              const SizedBox(height: 12),
              _featureCard(
                emoji: '👥',
                title: 'Klub',
                description: 'Hamfikrlar bilan suhbat va mini-darslar',
                accent: AppColors.neuronGreen,
              ),
              const SizedBox(height: 12),
              _featureCard(
                emoji: '🎖️',
                title: 'Klub musobaqasi',
                description: 'Jamoangiz bilan oylik chaqiriq',
                accent: AppColors.boboWarmth,
              ),
              const SizedBox(height: 28),
              _placeholderCard(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _featureCard({
    required String emoji,
    required String title,
    required String description,
    required Color accent,
  }) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppColors.cosmicMid,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: AppColors.cosmicLight.withValues(alpha: 0.15)),
      ),
      child: Row(
        children: [
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(
              color: accent.withValues(alpha: 0.14),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Center(child: Text(emoji, style: const TextStyle(fontSize: 26))),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: AppColors.pureWhite,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                      decoration: BoxDecoration(
                        color: AppColors.cosmicLight.withValues(alpha: 0.2),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Text(
                        'Tez orada',
                        style: TextStyle(
                          fontSize: 10,
                          color: AppColors.cosmicLight,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  description,
                  style: const TextStyle(
                    fontSize: 13,
                    color: AppColors.pureWhite,
                    height: 1.4,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    ).animate().fadeIn(duration: 400.ms).slideX(begin: 0.04);
  }

  Widget _placeholderCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            AppColors.plasmaYellow.withValues(alpha: 0.18),
            AppColors.cosmicMid,
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: AppColors.plasmaYellow.withValues(alpha: 0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Text('💫', style: TextStyle(fontSize: 28)),
              const SizedBox(width: 12),
              const Text(
                'Hozircha o\'zingiz bilan poyga',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: AppColors.pureWhite,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          const Text(
            'Har sessiyada yangi rekord o\'rnating. Tez orada do\'stlaringiz qo\'shiladi.',
            style: TextStyle(
              fontSize: 13,
              color: AppColors.pureWhite,
              height: 1.5,
            ),
          ),
        ],
      ),
    ).animate(delay: 600.ms).fadeIn().slideY(begin: 0.1);
  }
}
