import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../theme/app_colors.dart';
import '../games/shulte_game.dart';
import '../games/memory_matrix_game.dart';

/// "Laboratoriya" — o'yinlar dunyosi
/// Har bir o'yin — alohida eksperiment xonasi
class LabScreen extends StatelessWidget {
  const LabScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(gradient: AppColors.cosmicGradient),
      child: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _header(),
              const SizedBox(height: 24),
              _sectionLabel('Bugungi mashqlar'),
              const SizedBox(height: 12),
              _gameCard(
                context,
                emoji: '👁️',
                title: 'Shulte jadvali',
                category: 'E\'tibor',
                description: 'Vizual diqqat va periferik ko\'rishni mashq qiladi',
                accent: AppColors.uchqunGlow,
                duration: '3-5 daq',
                onTap: () => Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const ShulteGame()),
                ),
              ),
              const SizedBox(height: 10),
              _gameCard(
                context,
                emoji: '🧩',
                title: 'Xotira matritsasi',
                category: 'Xotira',
                description: 'Ishchi xotira va naqsh esda saqlash',
                accent: AppColors.neuronGreen,
                duration: '5-7 daq',
                onTap: () => Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const MemoryMatrixGame()),
                ),
              ),
              const SizedBox(height: 24),
              _sectionLabel('Tez orada'),
              const SizedBox(height: 12),
              _gameCard(
                context,
                emoji: '⚡',
                title: 'Ikki qaror',
                category: 'Tezlik',
                description: 'BrainHQ uslubidagi reaksiya tezligi',
                accent: AppColors.plasmaYellow,
                duration: '4-6 daq',
                comingSoon: true,
              ),
              const SizedBox(height: 10),
              _gameCard(
                context,
                emoji: '🎨',
                title: 'Stroop testi',
                category: 'Diqqat',
                description: 'Rang va so\'z konfliktini yengish',
                accent: AppColors.boboWarmth,
                duration: '3-5 daq',
                comingSoon: true,
              ),
              const SizedBox(height: 10),
              _gameCard(
                context,
                emoji: '➗',
                title: 'Tez hisob',
                category: 'Mantiq',
                description: 'Matematik chaqqonlik',
                accent: AppColors.accentRed,
                duration: '5-8 daq',
                comingSoon: true,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _header() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Laboratoriya',
          style: TextStyle(
            fontSize: 28,
            fontWeight: FontWeight.w700,
            color: AppColors.pureWhite,
          ),
        ).animate().fadeIn(),
        const SizedBox(height: 4),
        const Text(
          'Har xona — alohida eksperiment',
          style: TextStyle(color: AppColors.pureWhite, fontSize: 14),
        ),
      ],
    );
  }

  Widget _sectionLabel(String text) {
    return Padding(
      padding: const EdgeInsets.only(left: 4),
      child: Text(
        text.toUpperCase(),
        style: const TextStyle(
          color: AppColors.cosmicLight,
          fontSize: 11,
          fontWeight: FontWeight.w600,
          letterSpacing: 1.2,
        ),
      ),
    );
  }

  Widget _gameCard(
    BuildContext context, {
    required String emoji,
    required String title,
    required String category,
    required String description,
    required Color accent,
    required String duration,
    VoidCallback? onTap,
    bool comingSoon = false,
  }) {
    final available = !comingSoon;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(22),
        child: Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: AppColors.cosmicMid,
            borderRadius: BorderRadius.circular(22),
            border: Border.all(
              color: available
                  ? accent.withValues(alpha: 0.28)
                  : AppColors.cosmicLight.withValues(alpha: 0.15),
            ),
          ),
          child: Row(
            children: [
              Container(
                width: 56,
                height: 56,
                decoration: BoxDecoration(
                  color: accent.withValues(alpha: 0.14),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Center(
                  child: Text(
                    emoji,
                    style: TextStyle(
                      fontSize: 28,
                      color: available ? null : AppColors.cosmicLight,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(
                          title,
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: available
                                ? AppColors.pureWhite
                                : AppColors.cosmicLight,
                          ),
                        ),
                        if (!available) ...[
                          const SizedBox(width: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                            decoration: BoxDecoration(
                              color: AppColors.cosmicLight.withValues(alpha: 0.2),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: const Text(
                              'Tez orada',
                              style: TextStyle(
                                fontSize: 10,
                                color: AppColors.cosmicLight,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ],
                      ],
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        Text(
                          category,
                          style: TextStyle(
                            fontSize: 12,
                            color: accent,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        Text(
                          ' · $duration',
                          style: const TextStyle(
                            fontSize: 12,
                            color: AppColors.cosmicLight,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      description,
                      style: const TextStyle(
                        fontSize: 13,
                        color: AppColors.pureWhite,
                        height: 1.3,
                      ),
                    ),
                  ],
                ),
              ),
              if (available)
                const Icon(
                  Icons.chevron_right_rounded,
                  color: AppColors.pureWhite,
                ),
            ],
          ),
        ),
      ),
    ).animate().fadeIn(duration: 400.ms).slideX(begin: 0.04);
  }
}
