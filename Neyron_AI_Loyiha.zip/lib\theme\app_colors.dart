import 'package:flutter/material.dart';

/// Neyron AI rang palitrasi
/// Konsept: Futuristic Tea House — iliq personajlar + neon UI muhiti
class AppColors {
  // Asosiy fonlar — Kosmik kema ichi
  static const Color cosmicDeep = Color(0xFF0A1628);
  static const Color cosmicMid = Color(0xFF1A2942);
  static const Color cosmicLight = Color(0xFF2D3E5C);

  // Aksent ranglar
  static const Color neuronGreen = Color(0xFF00E5A0);
  static const Color plasmaYellow = Color(0xFFFFD93D);
  static const Color accentRed = Color(0xFFFF4757);
  static const Color pureWhite = Color(0xFFF7F9FC);

  // Iliq tomoni — Bobo + Maryam
  static const Color boboWarmth = Color(0xFFE8A87C);
  static const Color uchqunGlow = Color(0xFF7FDBFF);

  // 🆕 Neon UI ranglar — futuristic widgetlar uchun
  static const Color neonCyan = Color(0xFF00F5FF);        // Asosiy neon — kuchli
  static const Color neonTeal = Color(0xFF00D4C8);        // Yumshoqroq neon
  static const Color neonPurple = Color(0xFFB855FF);      // AI/Mind
  static const Color neonOrange = Color(0xFFFF8A3D);      // Iliq aksent

  // Gradientlar
  static const LinearGradient neuroplasticityGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [
      Color(0xFF7B2CBF),
      Color(0xFF3A86FF),
      Color(0xFF00B4D8),
    ],
  );

  static const LinearGradient cosmicGradient = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [
      Color(0xFF0A1628),
      Color(0xFF1A2942),
    ],
  );

  // 🆕 Neon progress gradient — Claude code uslubidagi
  static const LinearGradient neonProgressGradient = LinearGradient(
    begin: Alignment.centerLeft,
    end: Alignment.centerRight,
    colors: [
      Color(0xFF00F5FF),  // yorqin
      Color(0xFF00D4C8),
      Color(0xFF3A86FF),  // o'tib boruvchi
    ],
  );

  // 🆕 Neon yorug'lik (glow)
  static List<BoxShadow> neonGlow(Color color, {double intensity = 1.0}) => [
        BoxShadow(
          color: color.withValues(alpha: 0.3 * intensity),
          blurRadius: 12,
          spreadRadius: 1,
        ),
        BoxShadow(
          color: color.withValues(alpha: 0.15 * intensity),
          blurRadius: 24,
          spreadRadius: 4,
        ),
      ];
}
