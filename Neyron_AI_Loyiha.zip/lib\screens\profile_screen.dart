import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';
import '../models/user_profile.dart';
import '../services/app_state.dart';
import '../services/i18n.dart';
import '../theme/app_colors.dart';
import '../widgets/hero_characters.dart';
import 'onboarding_screen.dart';

/// Pasport — profil va sozlamalar
/// DESIGN.md: Tea House at Night, generous radii, tinted neutrals
class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final profile = state.profile!;
    final level = ((profile.totalSessions * 5) + (profile.streakDays * 2)).clamp(1, 100);

    return Container(
      decoration: const BoxDecoration(gradient: AppColors.cosmicGradient),
      child: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
          child: Column(
            children: [
              // 1. Foydalanuvchi avatari
              _userAvatar(profile),
              const SizedBox(height: 14),
              Text(
                profile.name,
                style: const TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.w600,
                  color: AppColors.pureWhite,
                ),
              ),
              const SizedBox(height: 6),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
                decoration: BoxDecoration(
                  color: AppColors.cosmicMid,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: AppColors.plasmaYellow.withValues(alpha: 0.3)),
                ),
                child: Text(
                  profile.ageGroup.displayName,
                  style: const TextStyle(color: AppColors.plasmaYellow, fontSize: 12, fontWeight: FontWeight.w600),
                ),
              ),
              const SizedBox(height: 24),

              // 2. Maryam (shogird) kartochkasi
              _maryamCard(level),
              const SizedBox(height: 18),

              // 3. Statistika
              Row(
                children: [
                  Expanded(child: _statTile('🔥', '${profile.streakDays}', 'Kun streak')),
                  const SizedBox(width: 10),
                  Expanded(child: _statTile('🎯', '${profile.totalSessions}', 'Sessiya')),
                  const SizedBox(width: 10),
                  Expanded(child: _statTile('🪙', '${profile.coins}', 'Tanga')),
                ],
              ),
              const SizedBox(height: 18),

              // 4. Ko'nikmalar
              _skillsCard(profile),
              const SizedBox(height: 24),

              // 5. Sozlamalar
              _settingsSection(context, state),
            ],
          ),
        ),
      ),
    );
  }

  // ─── USER AVATAR ──────────────────────────────────────────────
  Widget _userAvatar(UserProfile profile) {
    return Container(
      width: 92,
      height: 92,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: AppColors.neuroplasticityGradient,
        boxShadow: [
          BoxShadow(
            color: AppColors.uchqunGlow.withValues(alpha: 0.3),
            blurRadius: 20,
            spreadRadius: 2,
          ),
        ],
      ),
      child: Center(
        child: Text(
          profile.name.isNotEmpty ? profile.name[0].toUpperCase() : '?',
          style: const TextStyle(
            fontSize: 36,
            fontWeight: FontWeight.w600,
            color: AppColors.pureWhite,
          ),
        ),
      ),
    ).animate().fadeIn().scale(begin: const Offset(0.7, 0.7));
  }

  // ─── MARYAM CARD ──────────────────────────────────────────────
  Widget _maryamCard(int level) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.cosmicMid,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: AppColors.boboWarmth.withValues(alpha: 0.22)),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'Sizning shogirdingiz',
                style: TextStyle(
                  color: AppColors.pureWhite,
                  fontSize: 13,
                  fontWeight: FontWeight.w400,
                ),
              ),
              Text(
                I18n.maryamName,
                style: const TextStyle(
                  color: AppColors.boboWarmth,
                  fontWeight: FontWeight.w600,
                  fontSize: 14,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          MaryamImage(size: 130, level: level),
          const SizedBox(height: 18),
          Row(
            children: [
              const Expanded(
                child: Text(
                  'Daraja',
                  style: TextStyle(color: AppColors.pureWhite, fontSize: 13),
                ),
              ),
              Text(
                '$level / 100',
                style: const TextStyle(
                  color: AppColors.boboWarmth,
                  fontWeight: FontWeight.w600,
                  fontSize: 14,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: LinearProgressIndicator(
              value: level / 100,
              backgroundColor: AppColors.cosmicDeep,
              color: AppColors.boboWarmth,
              minHeight: 6,
            ),
          ),
        ],
      ),
    ).animate(delay: 150.ms).fadeIn().slideY(begin: 0.1);
  }

  // ─── STAT TILE ────────────────────────────────────────────────
  Widget _statTile(String emoji, String value, String label) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 14),
      decoration: BoxDecoration(
        color: AppColors.cosmicMid,
        borderRadius: BorderRadius.circular(18),
      ),
      child: Column(
        children: [
          Text(emoji, style: const TextStyle(fontSize: 22)),
          const SizedBox(height: 4),
          Text(
            value,
            style: const TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w600,
              color: AppColors.pureWhite,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            label,
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: AppColors.pureWhite,
              fontSize: 11,
            ),
          ),
        ],
      ),
    );
  }

  // ─── SKILLS ───────────────────────────────────────────────────
  Widget _skillsCard(UserProfile profile) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.cosmicMid,
        borderRadius: BorderRadius.circular(24),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Ko\'nikmalar',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: AppColors.pureWhite,
            ),
          ),
          const SizedBox(height: 18),
          _skillBar('Xotira', profile.skills['memory'] ?? 0, AppColors.neuronGreen),
          _skillBar('E\'tibor', profile.skills['attention'] ?? 0, AppColors.uchqunGlow),
          _skillBar('Mantiq', profile.skills['logic'] ?? 0, AppColors.plasmaYellow),
          _skillBar('Tezlik', profile.skills['speed'] ?? 0, AppColors.boboWarmth),
          _skillBar('Egiluvchanlik', profile.skills['flexibility'] ?? 0, AppColors.accentRed),
        ],
      ),
    ).animate(delay: 300.ms).fadeIn().slideY(begin: 0.1);
  }

  Widget _skillBar(String name, double value, Color color) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                name,
                style: const TextStyle(
                  fontSize: 13,
                  color: AppColors.pureWhite,
                ),
              ),
              Text(
                '${value.toInt()}',
                style: TextStyle(
                  color: color,
                  fontWeight: FontWeight.w600,
                  fontSize: 13,
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: LinearProgressIndicator(
              value: (value / 100).clamp(0, 1),
              backgroundColor: AppColors.cosmicDeep,
              color: color,
              minHeight: 5,
            ),
          ),
        ],
      ),
    );
  }

  // ─── SETTINGS ─────────────────────────────────────────────────
  Widget _settingsSection(BuildContext context, AppState state) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.only(left: 6, bottom: 10),
          child: Text(
            'Sozlamalar',
            style: TextStyle(
              fontSize: 13,
              color: AppColors.cosmicLight,
              letterSpacing: 0.5,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
        _settingsTile(
          context,
          icon: Icons.key_outlined,
          title: 'AI API kaliti',
          subtitle: state.hasApiKey ? 'O\'rnatilgan' : 'O\'rnatilmagan',
          onTap: () => _showApiKeyDialog(context, state),
        ),
        _settingsTile(
          context,
          icon: Icons.refresh_rounded,
          title: 'Profilni qayta yaratish',
          subtitle: 'Hammasini o\'chiradi',
          onTap: () => _confirmReset(context, state),
          isDanger: true,
        ),
      ],
    );
  }

  Widget _settingsTile(
    BuildContext context, {
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
    bool isDanger = false,
  }) {
    final accent = isDanger ? AppColors.accentRed : AppColors.pureWhite;
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: AppColors.cosmicMid,
        borderRadius: BorderRadius.circular(18),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(18),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            child: Row(
              children: [
                Container(
                  width: 38,
                  height: 38,
                  decoration: BoxDecoration(
                    color: accent.withValues(alpha: 0.12),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(icon, color: accent, size: 20),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: TextStyle(
                          color: accent,
                          fontSize: 15,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        subtitle,
                        style: const TextStyle(
                          color: AppColors.pureWhite,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
                const Icon(Icons.chevron_right_rounded, color: AppColors.cosmicLight),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ─── DIALOGS ──────────────────────────────────────────────────
  void _showApiKeyDialog(BuildContext context, AppState state) {
    final controller = TextEditingController(text: state.apiKey ?? '');
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppColors.cosmicMid,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: const Text(
          'Anthropic API kaliti',
          style: TextStyle(color: AppColors.pureWhite, fontSize: 18, fontWeight: FontWeight.w600),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Bobo Aql bilan AI suhbat uchun kerak.\nKalitni shu yerdan oling:',
              style: TextStyle(fontSize: 13, color: AppColors.pureWhite, height: 1.5),
            ),
            const SizedBox(height: 4),
            const Text(
              'console.anthropic.com/settings/keys',
              style: TextStyle(fontSize: 13, color: AppColors.neuronGreen),
            ),
            const SizedBox(height: 16),
            Container(
              decoration: BoxDecoration(
                color: AppColors.cosmicDeep,
                borderRadius: BorderRadius.circular(14),
              ),
              child: TextField(
                controller: controller,
                style: const TextStyle(color: AppColors.pureWhite, fontFamily: 'monospace'),
                decoration: const InputDecoration(
                  hintText: 'sk-ant-...',
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                  hintStyle: TextStyle(color: AppColors.cosmicLight),
                ),
                obscureText: true,
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Bekor', style: TextStyle(color: AppColors.cosmicLight)),
          ),
          ElevatedButton(
            onPressed: () async {
              await state.setApiKey(controller.text.trim());
              if (context.mounted) Navigator.pop(context);
            },
            child: const Text('Saqlash'),
          ),
        ],
      ),
    );
  }

  void _confirmReset(BuildContext context, AppState state) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppColors.cosmicMid,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: const Text(
          'Hammasini o\'chirish?',
          style: TextStyle(color: AppColors.pureWhite, fontSize: 18, fontWeight: FontWeight.w600),
        ),
        content: const Text(
          'Profilingiz, suhbatlar va statistika o\'chadi.\nBu qaytarib bo\'lmaydi.',
          style: TextStyle(color: AppColors.pureWhite, fontSize: 14, height: 1.5),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Bekor', style: TextStyle(color: AppColors.cosmicLight)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.accentRed,
              foregroundColor: AppColors.pureWhite,
            ),
            onPressed: () async {
              await state.reset();
              if (context.mounted) {
                Navigator.of(context).pushAndRemoveUntil(
                  MaterialPageRoute(builder: (_) => const OnboardingScreen()),
                  (_) => false,
                );
              }
            },
            child: const Text('O\'chirish'),
          ),
        ],
      ),
    );
  }
}
