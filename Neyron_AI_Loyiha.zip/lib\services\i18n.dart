import 'dart:ui';

/// Oddiy lokalizatsiya — keyinroq to'liq intl bilan almashtiriladi
/// Hozircha asosiy nomlar va matn til kodi bo'yicha tanlanadi
class I18n {
  /// Foydalanuvchining tilini aniqlash
  static String get currentLanguage {
    final code = PlatformDispatcher.instance.locale.languageCode;
    if (code == 'ru') return 'ru';
    if (code == 'en') return 'en';
    return 'uz'; // default: o'zbekcha
  }

  /// Mariya ismining tilga moslashgan shakli
  static String get maryamName {
    switch (currentLanguage) {
      case 'ru':
        return 'Мария';
      case 'en':
        return 'Mariya';
      default:
        return 'Mariya';
    }
  }

  /// Bobo Aql nomining tilga moslashgan shakli
  static String get boboAqlName {
    switch (currentLanguage) {
      case 'ru':
        return 'Дед Акл';
      case 'en':
        return 'Grandpa Wisdom';
      default:
        return 'Bobo Aql';
    }
  }
}
