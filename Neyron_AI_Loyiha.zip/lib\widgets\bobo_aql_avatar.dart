import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../theme/app_colors.dart';

/// Bobo Aql avatari — CSS-style chizilgan (rasm yo'q paytda)
/// Keyinroq haqiqiy rasm/Lottie animatsiya bilan almashtiriladi
class BoboAqlAvatar extends StatelessWidget {
  final double size;
  final bool animated;

  const BoboAqlAvatar({
    super.key,
    this.size = 120,
    this.animated = true,
  });

  @override
  Widget build(BuildContext context) {
    Widget avatar = Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: const RadialGradient(
          colors: [
            AppColors.boboWarmth,
            AppColors.cosmicMid,
          ],
        ),
        boxShadow: [
          BoxShadow(
            color: AppColors.boboWarmth.withValues(alpha: 0.4),
            blurRadius: 20,
            spreadRadius: 2,
          ),
        ],
      ),
      child: Stack(
        alignment: Alignment.center,
        children: [
          // Yuz
          Text(
            '🧙‍♂️',
            style: TextStyle(fontSize: size * 0.55),
          ),
          // Akademik shapkacha imitatsiya — yuqorida kichik element
          Positioned(
            top: size * 0.05,
            child: Container(
              width: size * 0.2,
              height: size * 0.05,
              decoration: BoxDecoration(
                color: AppColors.plasmaYellow.withValues(alpha: 0.6),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
        ],
      ),
    );

    if (!animated) return avatar;

    return avatar
        .animate(onPlay: (c) => c.repeat(reverse: true))
        .scale(
          begin: const Offset(1, 1),
          end: const Offset(1.03, 1.03),
          duration: 3.seconds,
          curve: Curves.easeInOut,
        );
  }
}
