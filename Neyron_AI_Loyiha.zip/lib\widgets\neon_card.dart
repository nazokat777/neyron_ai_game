import 'package:flutter/material.dart';
import '../theme/app_colors.dart';

/// Neon kartochka — yorqin chegara va ichki yorug'lik
/// Claude code uslubidagi futuristic widget
class NeonCard extends StatelessWidget {
  final Widget child;
  final Color glowColor;
  final EdgeInsetsGeometry? padding;
  final double radius;
  final double glowIntensity;
  final VoidCallback? onTap;

  const NeonCard({
    super.key,
    required this.child,
    this.glowColor = AppColors.neonCyan,
    this.padding,
    this.radius = 22,
    this.glowIntensity = 1.0,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final card = Container(
      padding: padding ?? const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.cosmicMid,
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(
          color: glowColor.withValues(alpha: 0.6),
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: glowColor.withValues(alpha: 0.25 * glowIntensity),
            blurRadius: 16,
            spreadRadius: 1,
          ),
          BoxShadow(
            color: glowColor.withValues(alpha: 0.1 * glowIntensity),
            blurRadius: 32,
            spreadRadius: 4,
          ),
        ],
      ),
      child: child,
    );

    if (onTap == null) return card;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(radius),
        child: card,
      ),
    );
  }
}

/// Neon progress bar — Claude code uslubidagi gradient
class NeonProgressBar extends StatelessWidget {
  final double value; // 0-1
  final double height;
  final Color trackColor;
  final Gradient? gradient;

  const NeonProgressBar({
    super.key,
    required this.value,
    this.height = 10,
    this.trackColor = AppColors.cosmicDeep,
    this.gradient,
  });

  @override
  Widget build(BuildContext context) {
    final clamped = value.clamp(0.0, 1.0);
    final g = gradient ?? AppColors.neonProgressGradient;
    return LayoutBuilder(
      builder: (context, constraints) {
        final w = constraints.maxWidth;
        return Container(
          height: height,
          decoration: BoxDecoration(
            color: trackColor,
            borderRadius: BorderRadius.circular(height / 2),
            border: Border.all(
              color: AppColors.neonCyan.withValues(alpha: 0.3),
              width: 1,
            ),
          ),
          child: Stack(
            children: [
              if (clamped > 0)
                AnimatedContainer(
                  duration: const Duration(milliseconds: 600),
                  curve: Curves.easeOutQuart,
                  width: w * clamped,
                  decoration: BoxDecoration(
                    gradient: g,
                    borderRadius: BorderRadius.circular(height / 2),
                    boxShadow: [
                      BoxShadow(
                        color: AppColors.neonCyan.withValues(alpha: 0.6),
                        blurRadius: 8,
                        spreadRadius: 0,
                      ),
                    ],
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}

/// Neon icon kvadrat — Claude code icondek
class NeonIconBox extends StatelessWidget {
  final IconData? icon;
  final String? emoji;
  final Color color;
  final double size;
  final double radius;

  const NeonIconBox({
    super.key,
    this.icon,
    this.emoji,
    this.color = AppColors.neonCyan,
    this.size = 56,
    this.radius = 14,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(
          color: color.withValues(alpha: 0.5),
          width: 1.2,
        ),
        boxShadow: [
          BoxShadow(
            color: color.withValues(alpha: 0.3),
            blurRadius: 10,
            spreadRadius: 0,
          ),
        ],
      ),
      child: Center(
        child: icon != null
            ? Icon(icon, color: color, size: size * 0.5)
            : Text(
                emoji ?? '',
                style: TextStyle(fontSize: size * 0.5),
              ),
      ),
    );
  }
}
