enum MessageRole { user, boboAql }

class Message {
  final String text;
  final MessageRole role;
  final DateTime timestamp;

  Message({
    required this.text,
    required this.role,
    DateTime? timestamp,
  }) : timestamp = timestamp ?? DateTime.now();

  bool get isFromBobo => role == MessageRole.boboAql;

  Map<String, dynamic> toJson() => {
        'text': text,
        'role': role.name,
        'timestamp': timestamp.toIso8601String(),
      };

  factory Message.fromJson(Map<String, dynamic> json) => Message(
        text: json['text'] as String,
        role: MessageRole.values.firstWhere((e) => e.name == json['role']),
        timestamp: DateTime.parse(json['timestamp'] as String),
      );
}
