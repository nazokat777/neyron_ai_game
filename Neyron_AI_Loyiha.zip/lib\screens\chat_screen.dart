import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';
import '../models/message.dart';
import '../services/app_state.dart';
import '../theme/app_colors.dart';
import '../widgets/hero_characters.dart';

/// Chat screen — Bobo Aql bilan suhbat
/// Tea House at Night: kechki choyxonadagi suhbat
class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _controller = TextEditingController();
  final _scrollController = ScrollController();

  @override
  void dispose() {
    _controller.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  Future<void> _send() async {
    final text = _controller.text.trim();
    if (text.isEmpty) return;
    _controller.clear();
    await context.read<AppState>().sendMessage(text);
    _scrollToBottom();
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final messages = state.messages;
    _scrollToBottom();

    return Scaffold(
      appBar: _buildAppBar(),
      body: Container(
        decoration: const BoxDecoration(gradient: AppColors.cosmicGradient),
        child: Column(
          children: [
            Expanded(
              child: messages.isEmpty ? _emptyState(state) : _messagesList(messages),
            ),
            if (state.isLoading) _typingIndicator(),
            _inputBar(state),
          ],
        ),
      ),
    );
  }

  // ─── APP BAR ──────────────────────────────────────────────────
  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: AppColors.cosmicDeep,
      elevation: 0,
      titleSpacing: 8,
      title: Row(
        children: [
          const BoboAqlImage(size: 38, animated: false),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  'Bobo Aql',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: AppColors.pureWhite,
                  ),
                ),
                Row(
                  children: [
                    Container(
                      width: 7,
                      height: 7,
                      decoration: const BoxDecoration(
                        color: AppColors.neuronGreen,
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 6),
                    const Text(
                      'choyxonada',
                      style: TextStyle(
                        fontSize: 12,
                        color: AppColors.pureWhite,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ─── EMPTY STATE ──────────────────────────────────────────────
  Widget _emptyState(AppState state) {
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const HeroCharacters(size: 240),
            const SizedBox(height: 28),
            Text(
              state.greeting(),
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 16,
                color: AppColors.pureWhite,
                height: 1.6,
                fontWeight: FontWeight.w400,
              ),
            ),
            const SizedBox(height: 12),
            const Text(
              'Quyiga yozing — choyimiz sovumasdan suhbatlashamiz.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 13,
                color: AppColors.cosmicLight,
                height: 1.5,
              ),
            ),
            if (!state.hasApiKey) ...[
              const SizedBox(height: 28),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppColors.cosmicMid,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: AppColors.plasmaYellow.withValues(alpha: 0.3)),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.key_outlined, color: AppColors.plasmaYellow, size: 20),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: const [
                          Text(
                            'AI suhbat uchun',
                            style: TextStyle(
                              color: AppColors.pureWhite,
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          SizedBox(height: 2),
                          Text(
                            'Pasport → AI API kalitini qo\'shing',
                            style: TextStyle(
                              color: AppColors.pureWhite,
                              fontSize: 13,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  // ─── MESSAGES LIST ────────────────────────────────────────────
  Widget _messagesList(List<Message> messages) {
    return ListView.builder(
      controller: _scrollController,
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
      itemCount: messages.length,
      itemBuilder: (_, i) => _messageBubble(messages[i]),
    );
  }

  Widget _messageBubble(Message msg) {
    final isBobo = msg.isFromBobo;
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Row(
        mainAxisAlignment: isBobo ? MainAxisAlignment.start : MainAxisAlignment.end,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          if (isBobo) ...[
            const BoboAqlImage(size: 34, animated: false),
            const SizedBox(width: 10),
          ],
          Flexible(
            child: Container(
              constraints: BoxConstraints(
                maxWidth: MediaQuery.of(context).size.width * 0.72,
              ),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: isBobo
                    ? AppColors.cosmicMid
                    : AppColors.neuronGreen.withValues(alpha: 0.18),
                borderRadius: BorderRadius.only(
                  topLeft: const Radius.circular(18),
                  topRight: const Radius.circular(18),
                  bottomLeft: Radius.circular(isBobo ? 4 : 18),
                  bottomRight: Radius.circular(isBobo ? 18 : 4),
                ),
                border: isBobo
                    ? Border.all(color: AppColors.boboWarmth.withValues(alpha: 0.22))
                    : null,
              ),
              child: Text(
                msg.text,
                style: TextStyle(
                  color: isBobo ? AppColors.pureWhite : AppColors.neuronGreen,
                  fontSize: 15,
                  height: 1.45,
                  fontWeight: FontWeight.w400,
                ),
              ),
            ),
          ),
        ],
      ),
    ).animate().fadeIn(duration: 200.ms).slideY(begin: 0.1, end: 0);
  }

  // ─── TYPING INDICATOR ─────────────────────────────────────────
  Widget _typingIndicator() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
      child: Row(
        children: [
          const BoboAqlImage(size: 28, animated: false),
          const SizedBox(width: 10),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              color: AppColors.cosmicMid,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: AppColors.boboWarmth.withValues(alpha: 0.22)),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: List.generate(
                3,
                (i) => Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 3),
                  child: Container(
                    width: 7,
                    height: 7,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: AppColors.boboWarmth.withValues(alpha: 0.7),
                    ),
                  )
                      .animate(
                        onPlay: (c) => c.repeat(),
                        delay: (i * 200).ms,
                      )
                      .fadeOut(duration: 600.ms)
                      .then()
                      .fadeIn(duration: 600.ms),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── INPUT BAR ────────────────────────────────────────────────
  Widget _inputBar(AppState state) {
    return Container(
      padding: EdgeInsets.fromLTRB(
        16,
        10,
        10,
        10 + MediaQuery.of(context).padding.bottom,
      ),
      decoration: const BoxDecoration(color: AppColors.cosmicMid),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Expanded(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              decoration: BoxDecoration(
                color: AppColors.cosmicDeep,
                borderRadius: BorderRadius.circular(20),
              ),
              child: TextField(
                controller: _controller,
                minLines: 1,
                maxLines: 5,
                style: const TextStyle(
                  fontSize: 15,
                  color: AppColors.pureWhite,
                  height: 1.4,
                ),
                decoration: const InputDecoration(
                  hintText: 'Bobo Aqlga yozing...',
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.symmetric(vertical: 12),
                  hintStyle: TextStyle(color: AppColors.cosmicLight, fontSize: 15),
                ),
                onSubmitted: (_) => _send(),
              ),
            ),
          ),
          const SizedBox(width: 8),
          GestureDetector(
            onTap: state.isLoading ? null : _send,
            child: AnimatedContainer(
              duration: 200.ms,
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: state.isLoading
                    ? AppColors.cosmicLight.withValues(alpha: 0.3)
                    : AppColors.neuronGreen,
                borderRadius: BorderRadius.circular(14),
              ),
              child: const Icon(
                Icons.arrow_upward_rounded,
                color: AppColors.cosmicDeep,
                size: 22,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
