import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../theme/app_colors.dart';

/// Uchqun — foydalanuvchi miyasining ramziy tasviri
/// Yorqin sharcha, atrofida neyron aloqalar
class UchqunWidget extends StatelessWidget {
  final double size;
  final int level; // 1-100, qancha katta — shuncha yorqin va katta

  const UchqunWidget({
    super.key,
    this.size = 80,
    this.level = 1,
  });

  @override
  Widget build(BuildContext context) {
    final intensity = (level / 100).clamp(0.3, 1.0);
    final coreSize = size * (0.5 + 0.3 * intensity);

    return SizedBox(
      width: size,
      height: size,
      child: Stack(
        alignment: Alignment.center,
        children: [
          // Tashqi nur halosi
          Container(
            width: size,
            height: size,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(
                colors: [
                  AppColors.uchqunGlow.withValues(alpha: 0.4 * intensity),
                  AppColors.uchqunGlow.withValues(alpha: 0.0),
                ],
              ),
            ),
          ).animate(onPlay: (c) => c.repeat()).scale(
                begin: const Offset(0.9, 0.9),
                end: const Offset(1.1, 1.1),
                duration: 2.seconds,
                curve: Curves.easeInOut,
              ),
          // Neyron aloqalar (chiziqlar)
          ..._buildNeurons(intensity),
          // Markaziy yorqin sharcha
          Container(
            width: coreSize,
            height: coreSize,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const RadialGradient(
                colors: [
                  Colors.white,
                  AppColors.uchqunGlow,
                ],
              ),
              boxShadow: [
                BoxShadow(
                  color: AppColors.uchqunGlow.withValues(alpha: 0.8 * intensity),
                  blurRadius: 20 * intensity,
                  spreadRadius: 4 * intensity,
                ),
              ],
            ),
          ).animate(onPlay: (c) => c.repeat(reverse: true)).fadeIn(
                duration: 1.5.seconds,
                begin: 0.7,
              ),
        ],
      ),
    );
  }

  List<Widget> _buildNeurons(double intensity) {
    final count = (4 + (intensity * 4)).round();
    final neurons = <Widget>[];
    final rng = Random(42);
    for (int i = 0; i < count; i++) {
      final angle = (2 * pi * i) / count;
      final distance = size * 0.35;
      final x = distance * cos(angle);
      final y = distance * sin(angle);

      neurons.add(
        Positioned(
          left: size / 2 + x - 3,
          top: size / 2 + y - 3,
          child: Container(
            width: 6,
            height: 6,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: AppColors.neuronGreen.withValues(alpha: 0.7),
              boxShadow: [
                BoxShadow(
                  color: AppColors.neuronGreen.withValues(alpha: 0.5),
                  blurRadius: 4,
                ),
              ],
            ),
          )
              .animate(
                onPlay: (c) => c.repeat(reverse: true),
                delay: (rng.nextInt(1000)).milliseconds,
              )
              .fadeIn(duration: 1.seconds)
              .then()
              .fadeOut(duration: 1.seconds),
        ),
      );
    }
    return neurons;
  }
}
