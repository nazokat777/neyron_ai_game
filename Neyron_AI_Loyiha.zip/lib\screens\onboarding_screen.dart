import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';
import '../models/user_profile.dart';
import '../services/app_state.dart';
import '../services/i18n.dart';
import '../theme/app_colors.dart';
import '../widgets/hero_characters.dart';
import 'main_navigation.dart';

/// Onboarding — birinchi sayohatchi sayohatga tayyorlanadi
/// 4 bosqich: salomlashish → ism → yosh → yakun
class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final _nameController = TextEditingController();
  int _age = 25;
  int _step = 0;

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  void _next() => setState(() => _step++);
  void _back() {
    if (_step > 0) setState(() => _step--);
  }

  Future<void> _finish() async {
    final name = _nameController.text.trim();
    if (name.isEmpty) return;

    final profile = UserProfile(
      name: name,
      age: _age,
      joinedDate: DateTime.now(),
    );

    final state = context.read<AppState>();
    final navigator = Navigator.of(context);
    await state.setProfile(profile);
    await state.incrementStreak();

    if (!mounted) return;
    navigator.pushReplacement(
      MaterialPageRoute(builder: (_) => const MainNavigation()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(gradient: AppColors.cosmicGradient),
        child: SafeArea(
          child: Column(
            children: [
              _progressBar(),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(24, 12, 24, 24),
                  child: AnimatedSwitcher(
                    duration: 400.ms,
                    child: KeyedSubtree(
                      key: ValueKey(_step),
                      child: _buildStep(),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ─── PROGRESS ─────────────────────────────────────────────────
  Widget _progressBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(24, 16, 24, 0),
      child: Row(
        children: [
          IconButton(
            onPressed: _step > 0 ? _back : null,
            icon: Icon(
              Icons.arrow_back_rounded,
              color: _step > 0 ? AppColors.pureWhite : Colors.transparent,
            ),
          ),
          Expanded(
            child: Row(
              children: List.generate(4, (i) {
                final isActive = i <= _step;
                return Expanded(
                  child: Container(
                    margin: const EdgeInsets.symmetric(horizontal: 3),
                    height: 4,
                    decoration: BoxDecoration(
                      color: isActive
                          ? AppColors.neuronGreen
                          : AppColors.cosmicMid,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                );
              }),
            ),
          ),
          const SizedBox(width: 48),
        ],
      ),
    );
  }

  Widget _buildStep() {
    switch (_step) {
      case 0:
        return _greetingStep();
      case 1:
        return _nameStep();
      case 2:
        return _ageStep();
      case 3:
        return _finishStep();
      default:
        return const SizedBox.shrink();
    }
  }

  // ─── STEP 1: GREETING ─────────────────────────────────────────
  Widget _greetingStep() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const HeroCharacters(size: 280)
            .animate()
            .fadeIn(duration: 800.ms)
            .scale(begin: const Offset(0.85, 0.85)),
        const SizedBox(height: 32),
        const Text(
          'Assalomu alaykum,\nqadrli mehmonim!',
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.w600,
            color: AppColors.pureWhite,
            height: 1.3,
          ),
          textAlign: TextAlign.center,
        ).animate(delay: 600.ms).fadeIn(),
        const SizedBox(height: 16),
        Text(
          'Men — Bobo Aql, bu esa shogirdim ${I18n.maryamName}.\nMiya Sayyorasiga birga sayohat qilamiz.',
          style: const TextStyle(
            fontSize: 15,
            color: AppColors.pureWhite,
            height: 1.6,
          ),
          textAlign: TextAlign.center,
        ).animate(delay: 900.ms).fadeIn(),
        const SizedBox(height: 40),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton(
            onPressed: _next,
            child: const Text('Sayohatni boshlash'),
          ),
        ).animate(delay: 1200.ms).fadeIn(),
      ],
    );
  }

  // ─── STEP 2: NAME ─────────────────────────────────────────────
  Widget _nameStep() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const BoboAqlImage(size: 110),
        const SizedBox(height: 28),
        const Text(
          'Avval tanishaylik.\nIsmingizni ayting:',
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.w600,
            color: AppColors.pureWhite,
            height: 1.4,
          ),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 28),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 4),
          decoration: BoxDecoration(
            color: AppColors.cosmicMid,
            borderRadius: BorderRadius.circular(20),
          ),
          child: TextField(
            controller: _nameController,
            textAlign: TextAlign.center,
            autofocus: true,
            style: const TextStyle(
              fontSize: 22,
              color: AppColors.pureWhite,
              fontWeight: FontWeight.w500,
            ),
            decoration: const InputDecoration(
              hintText: 'Ismingiz',
              hintStyle: TextStyle(color: AppColors.cosmicLight, fontWeight: FontWeight.w400),
              border: InputBorder.none,
              contentPadding: EdgeInsets.symmetric(vertical: 18),
            ),
            onSubmitted: (_) => _next(),
            onChanged: (_) => setState(() {}),
          ),
        ),
        const SizedBox(height: 32),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton(
            onPressed: _nameController.text.trim().isEmpty ? null : _next,
            child: const Text('Davom etish'),
          ),
        ),
      ],
    );
  }

  // ─── STEP 3: AGE ──────────────────────────────────────────────
  Widget _ageStep() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const BoboAqlImage(size: 90),
        const SizedBox(height: 24),
        Text(
          'Yoshingiz, ${_nameController.text}?',
          style: const TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.w600,
            color: AppColors.pureWhite,
          ),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 8),
        const Text(
          'Sizga mos sayohat tanlashga yordam beradi',
          style: TextStyle(
            fontSize: 13,
            color: AppColors.pureWhite,
          ),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 28),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 36, vertical: 18),
          decoration: BoxDecoration(
            color: AppColors.cosmicMid,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: AppColors.boboWarmth.withValues(alpha: 0.25)),
          ),
          child: Text(
            '$_age',
            style: const TextStyle(
              fontSize: 56,
              fontWeight: FontWeight.w300,
              color: AppColors.pureWhite,
            ),
          ),
        ),
        const SizedBox(height: 18),
        SliderTheme(
          data: SliderTheme.of(context).copyWith(
            trackHeight: 5,
            thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 11),
            overlayShape: const RoundSliderOverlayShape(overlayRadius: 20),
          ),
          child: Slider(
            value: _age.toDouble(),
            min: 3,
            max: 70,
            divisions: 67,
            activeColor: AppColors.neuronGreen,
            inactiveColor: AppColors.cosmicMid,
            onChanged: (v) => setState(() => _age = v.round()),
          ),
        ),
        const SizedBox(height: 6),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
          decoration: BoxDecoration(
            color: AppColors.cosmicMid,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: AppColors.plasmaYellow.withValues(alpha: 0.3)),
          ),
          child: Text(
            AgeGroup.fromAge(_age).displayName,
            style: const TextStyle(
              color: AppColors.plasmaYellow,
              fontSize: 13,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
        const SizedBox(height: 36),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton(
            onPressed: _next,
            child: const Text('Davom etish'),
          ),
        ),
      ],
    );
  }

  // ─── STEP 4: FINISH ───────────────────────────────────────────
  Widget _finishStep() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const HeroCharacters(size: 240)
            .animate()
            .fadeIn(duration: 600.ms)
            .scale(begin: const Offset(0.85, 0.85)),
        const SizedBox(height: 32),
        Text(
          'Xush kelibsiz, ${_nameController.text}!',
          style: const TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.w600,
            color: AppColors.pureWhite,
          ),
          textAlign: TextAlign.center,
        ).animate(delay: 400.ms).fadeIn(),
        const SizedBox(height: 16),
        Text(
          'Sizning Miya Sayyorangiz tayyor.\n${I18n.maryamName} sizni kutib turibdi.',
          style: const TextStyle(
            fontSize: 15,
            color: AppColors.pureWhite,
            height: 1.6,
          ),
          textAlign: TextAlign.center,
        ).animate(delay: 700.ms).fadeIn(),
        const SizedBox(height: 40),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton(
            onPressed: _finish,
            child: const Text('Sayyoraga kirish'),
          ),
        ).animate(delay: 1000.ms).fadeIn(),
      ],
    );
  }
}
