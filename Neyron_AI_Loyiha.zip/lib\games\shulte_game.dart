import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';
import '../services/app_state.dart';
import '../theme/app_colors.dart';
import '../widgets/hero_characters.dart';

/// Shulte jadvali — vizual diqqat va periferik ko'rish mashqi
/// Ilmiy asos: Walter Schulte (1920), 47% diqqat yaxshilanishi (8 hafta mashq)
class ShulteGame extends StatefulWidget {
  const ShulteGame({super.key});

  @override
  State<ShulteGame> createState() => _ShulteGameState();
}

class _ShulteGameState extends State<ShulteGame> {
  static const int gridSize = 5; // 5x5
  static const int totalCells = gridSize * gridSize;

  late List<int> _numbers;
  int _nextNumber = 1;
  DateTime? _startTime;
  Duration? _elapsedTime;
  bool _finished = false;
  int _mistakes = 0;
  int _lastWrongIndex = -1;

  @override
  void initState() {
    super.initState();
    _reset();
  }

  void _reset() {
    _numbers = List.generate(totalCells, (i) => i + 1)..shuffle(Random());
    _nextNumber = 1;
    _startTime = null;
    _elapsedTime = null;
    _finished = false;
    _mistakes = 0;
    _lastWrongIndex = -1;
    setState(() {});
  }

  void _onTap(int number, int index) {
    if (_finished) return;
    _startTime ??= DateTime.now();

    if (number == _nextNumber) {
      setState(() {
        _nextNumber++;
        if (_nextNumber > totalCells) {
          _finished = true;
          _elapsedTime = DateTime.now().difference(_startTime!);
          _awardXp();
        }
      });
    } else {
      setState(() {
        _mistakes++;
        _lastWrongIndex = index;
      });
      Future.delayed(const Duration(milliseconds: 300), () {
        if (mounted) setState(() => _lastWrongIndex = -1);
      });
    }
  }

  Future<void> _awardXp() async {
    final state = context.read<AppState>();
    await state.incrementSessions();

    // XP hisoblash: tezroq + kam xato = ko'proq tanga
    final seconds = _elapsedTime!.inSeconds;
    final baseCoins = 10;
    final speedBonus = (60 - seconds).clamp(0, 60) ~/ 6;
    final mistakePenalty = _mistakes * 2;
    final coins = (baseCoins + speedBonus - mistakePenalty).clamp(1, 50);
    await state.addCoins(coins);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Shulte jadvali'),
        backgroundColor: Colors.transparent,
      ),
      body: Container(
        decoration: const BoxDecoration(gradient: AppColors.cosmicGradient),
        child: SafeArea(
          child: Column(
            children: [
              const SizedBox(height: 8),
              _statusBar(),
              const SizedBox(height: 16),
              Expanded(child: _buildGrid()),
              if (_finished) _resultCard(),
              const SizedBox(height: 16),
            ],
          ),
        ),
      ),
    );
  }

  Widget _statusBar() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.cosmicMid,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Keyingisini toping', style: TextStyle(color: AppColors.cosmicLight, fontSize: 12)),
              const SizedBox(height: 4),
              Text(
                _finished ? '✓' : '$_nextNumber',
                style: const TextStyle(
                  fontSize: 32,
                  fontWeight: FontWeight.w600,
                  color: AppColors.neuronGreen,
                ),
              ),
            ],
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              const Text('Xatolar', style: TextStyle(color: AppColors.cosmicLight, fontSize: 12)),
              const SizedBox(height: 4),
              Text(
                '$_mistakes',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w600,
                  color: _mistakes > 0 ? AppColors.accentRed : AppColors.cosmicLight,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildGrid() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: AspectRatio(
        aspectRatio: 1,
        child: GridView.builder(
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: gridSize,
            crossAxisSpacing: 6,
            mainAxisSpacing: 6,
          ),
          itemCount: totalCells,
          itemBuilder: (_, i) => _buildCell(i),
        ),
      ),
    );
  }

  Widget _buildCell(int index) {
    final number = _numbers[index];
    final isFound = number < _nextNumber;
    final isNext = number == _nextNumber;
    final isWrong = index == _lastWrongIndex;

    Color bg = AppColors.cosmicMid;
    if (isFound) bg = AppColors.neuronGreen.withValues(alpha: 0.3);
    if (isWrong) bg = AppColors.accentRed.withValues(alpha: 0.4);

    return GestureDetector(
      onTap: () => _onTap(number, index),
      child: Container(
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(12),
          border: isNext
              ? Border.all(color: AppColors.plasmaYellow, width: 2)
              : Border.all(color: AppColors.cosmicLight.withValues(alpha: 0.2)),
        ),
        child: Center(
          child: Text(
            isFound ? '✓' : '$number',
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.w600,
              color: isFound ? AppColors.neuronGreen : AppColors.pureWhite,
            ),
          ),
        ),
      ).animate(target: isWrong ? 1 : 0).shake(hz: 6, curve: Curves.easeInOut, duration: 300.ms),
    );
  }

  Widget _resultCard() {
    final seconds = _elapsedTime!.inSeconds;
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.cosmicMid,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: AppColors.boboWarmth.withValues(alpha: 0.3)),
      ),
      child: Column(
        children: [
          const CelebrationImage(size: 140),
          const SizedBox(height: 12),
          const Text(
            'Zo\'r natija!',
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.w600,
              color: AppColors.pureWhite,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            'Vaqt: $seconds soniya · Xatolar: $_mistakes',
            style: const TextStyle(color: AppColors.pureWhite, fontSize: 14),
          ),
          const SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ElevatedButton(
                onPressed: _reset,
                child: const Text('Yana o\'ynash'),
              ),
              const SizedBox(width: 12),
              OutlinedButton(
                onPressed: () => Navigator.of(context).pop(),
                style: OutlinedButton.styleFrom(
                  foregroundColor: AppColors.pureWhite,
                  side: const BorderSide(color: AppColors.cosmicLight),
                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                ),
                child: const Text('Chiqish'),
              ),
            ],
          ),
        ],
      ),
    ).animate().fadeIn().slideY(begin: 0.3);
  }
}
