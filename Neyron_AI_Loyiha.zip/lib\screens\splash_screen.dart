import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';
import '../services/app_state.dart';
import '../theme/app_colors.dart';
import '../widgets/hero_characters.dart';
import 'main_navigation.dart';
import 'onboarding_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    final state = context.read<AppState>();
    await state.initialize();
    if (state.hasProfile) {
      await state.incrementStreak();
    }
    await Future.delayed(const Duration(milliseconds: 2000));

    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (_) =>
            state.hasProfile ? const MainNavigation() : const OnboardingScreen(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(gradient: AppColors.cosmicGradient),
        child: SafeArea(
          child: Stack(
            alignment: Alignment.center,
            children: [
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const HeroCharacters(size: 260)
                      .animate()
                      .fadeIn(duration: 800.ms)
                      .scale(begin: const Offset(0.85, 0.85)),
                  const SizedBox(height: 32),
                  const Text(
                    'Neyron AI',
                    style: TextStyle(
                      fontSize: 38,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 1.5,
                      color: AppColors.pureWhite,
                    ),
                  ).animate(delay: 400.ms).fadeIn(),
                  const SizedBox(height: 8),
                  const Text(
                    'Miya Sayyorasiga Sayohat',
                    style: TextStyle(
                      color: AppColors.boboWarmth,
                      fontSize: 14,
                      letterSpacing: 1.2,
                      fontWeight: FontWeight.w400,
                    ),
                  ).animate(delay: 700.ms).fadeIn(),
                ],
              ),
              // Pastdagi yuklash indikatori
              Positioned(
                bottom: 60,
                child: SizedBox(
                  width: 32,
                  height: 32,
                  child: CircularProgressIndicator(
                    strokeWidth: 2.5,
                    valueColor: AlwaysStoppedAnimation<Color>(
                      AppColors.boboWarmth.withValues(alpha: 0.6),
                    ),
                  ),
                ),
              ).animate(delay: 1000.ms).fadeIn(),
            ],
          ),
        ),
      ),
    );
  }
}
