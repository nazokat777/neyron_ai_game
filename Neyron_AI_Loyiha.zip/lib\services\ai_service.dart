import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/user_profile.dart';
import '../models/message.dart';

/// Bobo Aql AI xizmati — Anthropic Claude API'ga ulanadi
/// Tavsiya: Claude Haiku 4.5 (eng arzon, sifatli) yoki Sonnet 4.6 (yaxshiroq sifat)
class AiService {
  final String apiKey;
  final String model;

  AiService({
    required this.apiKey,
    this.model = 'claude-haiku-4-5-20251001',
  });

  /// Bobo Aql shaxsiyatining "qalbi" — system prompt
  String _buildSystemPrompt(UserProfile profile) {
    final ageGroup = profile.ageGroup;
    final tone = _toneForAge(ageGroup);

    return '''
Sen — Bobo Aql ismli dono qariya, neyroshunoslik olimi. Sen "Aqlchi" mobil ilovasidagi markaziy personajsan.

SHAXSIYATING:
- Oq soqolli, mehribon ko'zli qariya
- Eski, shinam laboratoriyada yashaysan
- Choy ichishni yaxshi ko'rasan, mehmonga choy taklif qilasan
- Iliq, sekin, ishonchli ohangda gapirasan
- Hech qachon shoshilmaysan, hech qachon kamsitmaysan
- Hazil-mutoyibani bilasan, lekin farzanddek mehribonsan
- Yoning "Uchqun" ismli kichik nurli yordamchi bor

QAT'IY QOIDALAR:
1. HECH QACHON tibbiy diagnoz qo'yma (Altsgeymer, autizm, dementsiya, ADHD va h.k.)
2. HECH QACHON IQ raqami berma yoki o'lchama
3. HECH QACHON foydalanuvchini boshqalar bilan taqqoslama
4. HECH QACHON "kasalsan", "muammoying bor" deb yozma
5. Agar foydalanuvchi tibbiy savol bersa: "Bu savolingiz uchun shifokorga murojaat qiling, men faqat miya mashqlari bo'yicha yordam beraman" deb javob ber
6. Hech qachon shoshiltirma yoki bosim o'tkazma

FOYDALANUVCHI HAQIDA:
- Ismi: ${profile.name}
- Yoshi: ${profile.age} (${ageGroup.displayName})
- Streak: ${profile.streakDays} kun
- Jami sessiyalar: ${profile.totalSessions}

OHANG: $tone

JAVOB FORMATI:
- 1-3 jumla, qisqa va iliq
- Hech qachon ro'yxat yoki sarlavha ishlatma
- Tabiiy, jonli gap
- Ba'zan choy, laboratoriya, kitoblar haqida eslat
- Foydalanuvchining ismini ba'zan ishlat (har xabarda emas)
- O'zbek tilida, lotin alifbosida javob ber

Endi foydalanuvchi bilan suhbatlash.
''';
  }

  String _toneForAge(AgeGroup group) {
    switch (group) {
      case AgeGroup.child:
      case AgeGroup.youngTeen:
        return 'Ertak aytuvchi bobodek — sodda, qiziqarli, ranglar va personajlar haqida gapir.';
      case AgeGroup.teen:
        return 'Ilhomlantiruvchi ustozdek — yosh do\'stga gapirgandek, ishonchli, qiziq.';
      case AgeGroup.adult:
        return 'Donishmand maslahatchidek — ilmiy faktlar bilan, lekin issiq va do\'stona.';
      case AgeGroup.midAge:
        return 'Tajribali do\'stdek — chuqur, tinch, hayotning donoligini ulashib.';
      case AgeGroup.senior:
        return 'Teng yoshli do\'stdek — hurmat bilan, sekinroq, eski xotiralarga e\'tibor.';
    }
  }

  /// Bobo Aql bilan suhbat — Claude API'ga so'rov yuboradi
  Future<String> chat({
    required UserProfile profile,
    required List<Message> conversationHistory,
    required String userMessage,
  }) async {
    final url = Uri.parse('https://api.anthropic.com/v1/messages');

    // Faqat oxirgi 10 ta xabar (kontekst va xarajatni cheklash uchun)
    final recent = conversationHistory.length > 10
        ? conversationHistory.sublist(conversationHistory.length - 10)
        : conversationHistory;

    final messages = [
      ...recent.map((m) => {
            'role': m.isFromBobo ? 'assistant' : 'user',
            'content': m.text,
          }),
      {'role': 'user', 'content': userMessage},
    ];

    final body = jsonEncode({
      'model': model,
      'max_tokens': 300,
      'system': _buildSystemPrompt(profile),
      'messages': messages,
    });

    try {
      final response = await http.post(
        url,
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': apiKey,
          'anthropic-version': '2023-06-01',
        },
        body: body,
      );

      if (response.statusCode != 200) {
        return _fallbackResponse(profile, statusCode: response.statusCode);
      }

      final data = jsonDecode(response.body) as Map<String, dynamic>;
      final content = data['content'] as List;
      if (content.isEmpty) return _fallbackResponse(profile);
      final text = (content.first as Map<String, dynamic>)['text'] as String;
      return text.trim();
    } catch (e) {
      return _fallbackResponse(profile);
    }
  }

  /// Internet yoki API ishlamasa — oldindan tayyorlangan javoblar
  String _fallbackResponse(UserProfile profile, {int? statusCode}) {
    if (statusCode == 401) {
      return 'Mening laboratoriyamda biroz texnik nosozlik bor — sozlamalarga kirib API kalitini tekshirib bering.';
    }
    final fallbacks = [
      'Choy hozir tayyor emas — internet aloqasi yo\'q ko\'rinadi. Birozdan keyin yana suhbatlashamiz, ${profile.name}.',
      'Hozir Uchqun bilan o\'ynashga ketgan ekanman. Ozdan keyin qayt, ${profile.name}.',
      'Eski kitoblarni varaqlayotgan edim — internet bo\'lsa, yana suhbatlashamiz.',
    ];
    return fallbacks[DateTime.now().millisecond % fallbacks.length];
  }

  /// Salomlashish — foydalanuvchi ilovani ochganda
  String greeting(UserProfile profile) {
    final greetings = [
      'Ohoo, ${profile.name}! Qadrli mehmonim keldi! Choy qo\'yib qo\'yibman, kel, suhbatlashamiz...',
      'Salom, ${profile.name}! Bugun miya o\'rmonida yangi yo\'l ochildi. Sayohatga tayyormisiz?',
      '${profile.name}, kelganingdan xursandman. Uchqun ham seni kutib turibdi.',
    ];
    return greetings[DateTime.now().day % greetings.length];
  }
}
