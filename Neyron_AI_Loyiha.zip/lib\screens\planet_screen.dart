import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';
import '../models/user_profile.dart';
import '../services/app_state.dart';
import '../services/i18n.dart';
import '../theme/app_colors.dart';
import '../widgets/hero_characters.dart';
import '../widgets/neon_card.dart';
import 'chat_screen.dart';

/// "Sayyora" — bosh sahifa
/// Konsept: Futuristic Tea House
/// Iliq personajlar (Bobo + Maryam) + Neon UI (kosmik kema)
class PlanetScreen extends StatelessWidget {
  const PlanetScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final profile = state.profile!;

    return Container(
      decoration: const BoxDecoration(gradient: AppColors.cosmicGradient),
      child: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _topBar(profile),
              const SizedBox(height: 24),

              // HERO — iliq personajlar (o'zgartirilmagan)
              _heroSection(context),
              const SizedBox(height: 20),

              // Bobo Aql kartochkasi — iliq, neon glow bilan
              _greetingCard(context, state),
              const SizedBox(height: 14),

              // Maryam progress — Claude code uslubidagi neon bar
              _maryamNeonProgress(profile),
              const SizedBox(height: 14),

              // Bugungi mashqlar progress — Claude code uslubida
              _todayProgress(profile),
              const SizedBox(height: 14),

              // Sehrli quti
              _magicBox(),
              const SizedBox(height: 18),

              // Statistika
              _statsRow(profile),
            ],
          ),
        ),
      ),
    );
  }

  // ─── TOP BAR ──────────────────────────────────────────────────
  Widget _topBar(UserProfile profile) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        _neonPill('🔥', '${profile.streakDays}', 'kun', AppColors.plasmaYellow),
        _neonPill('🪙', '${profile.coins}', '', AppColors.neonCyan),
      ],
    );
  }

  Widget _neonPill(String emoji, String value, String unit, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(
        color: AppColors.cosmicMid,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withValues(alpha: 0.55), width: 1.2),
        boxShadow: [
          BoxShadow(
            color: color.withValues(alpha: 0.25),
            blurRadius: 12,
            spreadRadius: 0,
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(emoji, style: const TextStyle(fontSize: 16)),
          const SizedBox(width: 8),
          Text(
            value,
            style: TextStyle(
              color: color,
              fontWeight: FontWeight.w600,
              fontSize: 15,
            ),
          ),
          if (unit.isNotEmpty) ...[
            const SizedBox(width: 4),
            Text(
              unit,
              style: const TextStyle(
                color: AppColors.pureWhite,
                fontSize: 12,
                fontWeight: FontWeight.w400,
              ),
            ),
          ],
        ],
      ),
    );
  }

  // ─── HERO ─────────────────────────────────────────────────────
  Widget _heroSection(BuildContext context) {
    final screenW = MediaQuery.of(context).size.width;
    return Center(
      child: HeroCharacters(size: screenW - 80),
    ).animate().fadeIn(duration: 800.ms).scale(begin: const Offset(0.9, 0.9));
  }

  // ─── GREETING CARD — iliq, lekin neon glow bilan ──────────────
  Widget _greetingCard(BuildContext context, AppState state) {
    final profile = state.profile!;
    return NeonCard(
      glowColor: AppColors.boboWarmth,
      glowIntensity: 0.7,
      radius: 22,
      padding: const EdgeInsets.all(18),
      onTap: () => Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => const ChatScreen()),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Text(
                'Bobo Aql',
                style: TextStyle(
                  color: AppColors.boboWarmth,
                  fontWeight: FontWeight.w600,
                  fontSize: 13,
                  letterSpacing: 0.4,
                ),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: AppColors.neuronGreen.withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: AppColors.neuronGreen.withValues(alpha: 0.4)),
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.chat_bubble_outline, color: AppColors.neuronGreen, size: 11),
                    SizedBox(width: 4),
                    Text(
                      'Suhbat',
                      style: TextStyle(
                        color: AppColors.neuronGreen,
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            'Salom, ${profile.name}. Choy qo\'yib qo\'yibman — kel, suhbatlashamiz.',
            style: const TextStyle(
              fontSize: 15,
              color: AppColors.pureWhite,
              height: 1.5,
            ),
          ),
        ],
      ),
    ).animate(delay: 200.ms).fadeIn().slideY(begin: 0.1);
  }

  // ─── MARYAM NEON PROGRESS ─────────────────────────────────────
  Widget _maryamNeonProgress(UserProfile profile) {
    final level = ((profile.totalSessions * 5) + (profile.streakDays * 2)).clamp(1, 100);
    return NeonCard(
      glowColor: AppColors.neonCyan,
      glowIntensity: 0.8,
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          MaryamImage(size: 56, level: level, animated: true),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(
                      I18n.maryamName,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: AppColors.pureWhite,
                      ),
                    ),
                    const Spacer(),
                    Text(
                      '$level',
                      style: const TextStyle(
                        color: AppColors.neonCyan,
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        fontFeatures: [FontFeature.tabularFigures()],
                      ),
                    ),
                    const Text(
                      ' / 100',
                      style: TextStyle(
                        color: AppColors.cosmicLight,
                        fontSize: 13,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                NeonProgressBar(value: level / 100, height: 8),
              ],
            ),
          ),
        ],
      ),
    ).animate(delay: 350.ms).fadeIn().slideY(begin: 0.1);
  }

  // ─── TODAY PROGRESS — Claude code style ───────────────────────
  Widget _todayProgress(UserProfile profile) {
    final done = (profile.totalSessions % 3).clamp(0, 3);
    final goal = 3;
    return NeonCard(
      glowColor: AppColors.neonPurple,
      glowIntensity: 0.8,
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          const NeonIconBox(
            emoji: '🧠',
            color: AppColors.neonPurple,
            size: 56,
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Text(
                      'Bugungi maqsad',
                      style: TextStyle(
                        color: AppColors.pureWhite,
                        fontSize: 15,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const Spacer(),
                    Text(
                      '$done / $goal',
                      style: const TextStyle(
                        color: AppColors.neonPurple,
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        fontFeatures: [FontFeature.tabularFigures()],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                NeonProgressBar(
                  value: done / goal,
                  height: 8,
                  gradient: LinearGradient(
                    colors: [
                      AppColors.neonPurple.withValues(alpha: 0.95),
                      AppColors.neonCyan.withValues(alpha: 0.7),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    ).animate(delay: 500.ms).fadeIn().slideY(begin: 0.1);
  }

  // ─── MAGIC BOX ────────────────────────────────────────────────
  Widget _magicBox() {
    return NeonCard(
      glowColor: AppColors.plasmaYellow,
      glowIntensity: 0.7,
      child: Row(
        children: [
          const NeonIconBox(
            emoji: '📦',
            color: AppColors.plasmaYellow,
            size: 56,
          ),
          const SizedBox(width: 14),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Sehrli quti',
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 16,
                    color: AppColors.pureWhite,
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  'Bugun 3 ta mashq qoldirilgan',
                  style: TextStyle(
                    color: AppColors.pureWhite,
                    fontSize: 13,
                    height: 1.4,
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: AppColors.plasmaYellow.withValues(alpha: 0.18),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColors.plasmaYellow.withValues(alpha: 0.5)),
            ),
            child: const Icon(Icons.unarchive_outlined,
                color: AppColors.plasmaYellow, size: 22),
          ),
        ],
      ),
    ).animate(delay: 650.ms).fadeIn().slideY(begin: 0.1);
  }

  // ─── STATS ────────────────────────────────────────────────────
  Widget _statsRow(UserProfile profile) {
    final totalXp = profile.skills.values.fold<double>(0, (a, b) => a + b).toInt();
    final daysWith = DateTime.now().difference(profile.joinedDate).inDays + 1;
    return Row(
      children: [
        Expanded(child: _statTile('🎯', '${profile.totalSessions}', 'Sessiya', AppColors.neonCyan)),
        const SizedBox(width: 10),
        Expanded(child: _statTile('⭐', '$totalXp', 'XP', AppColors.plasmaYellow)),
        const SizedBox(width: 10),
        Expanded(child: _statTile('📅', '$daysWith', 'Kun', AppColors.neonPurple)),
      ],
    ).animate(delay: 800.ms).fadeIn().slideY(begin: 0.1);
  }

  Widget _statTile(String emoji, String value, String label, Color glow) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 14),
      decoration: BoxDecoration(
        color: AppColors.cosmicMid,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: glow.withValues(alpha: 0.35), width: 1),
        boxShadow: [
          BoxShadow(
            color: glow.withValues(alpha: 0.15),
            blurRadius: 10,
            spreadRadius: 0,
          ),
        ],
      ),
      child: Column(
        children: [
          Text(emoji, style: const TextStyle(fontSize: 22)),
          const SizedBox(height: 4),
          Text(
            value,
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w600,
              color: glow,
              fontFeatures: const [FontFeature.tabularFigures()],
            ),
          ),
          const SizedBox(height: 2),
          Text(
            label,
            style: const TextStyle(
              color: AppColors.pureWhite,
              fontSize: 11,
            ),
          ),
        ],
      ),
    );
  }
}