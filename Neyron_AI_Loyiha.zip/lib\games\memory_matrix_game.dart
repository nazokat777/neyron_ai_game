import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';
import '../services/app_state.dart';
import '../theme/app_colors.dart';

/// Memory Matrix — naqshni eslab qolish va takrorlash
/// Ilmiy asos: Ishchi xotira (Working Memory), dorsolateral prefrontal cortex
class MemoryMatrixGame extends StatefulWidget {
  const MemoryMatrixGame({super.key});

  @override
  State<MemoryMatrixGame> createState() => _MemoryMatrixGameState();
}

enum _GamePhase { ready, memorize, recall, correct, wrong, finished }

class _MemoryMatrixGameState extends State<MemoryMatrixGame> {
  // Daraja → grid kattaligi va belgilangan kataklar soni
  int _level = 1;
  late int _gridSize;
  late int _targetCount;
  late Set<int> _target;
  Set<int> _selected = {};
  _GamePhase _phase = _GamePhase.ready;
  int _score = 0;
  int _lives = 3;

  @override
  void initState() {
    super.initState();
    _startLevel();
  }

  void _startLevel() {
    final cfg = _configFor(_level);
    _gridSize = cfg.$1;
    _targetCount = cfg.$2;
    _target = _randomCells(_gridSize * _gridSize, _targetCount);
    _selected = {};
    _phase = _GamePhase.ready;
    setState(() {});

    // 1 soniya kutib, memorize fazaga o'tish
    Future.delayed(const Duration(milliseconds: 800), () {
      if (!mounted) return;
      setState(() => _phase = _GamePhase.memorize);
      // Memorize davomiyligi darajaga qarab
      final memorizeMs = 1500 + (_targetCount * 300);
      Future.delayed(Duration(milliseconds: memorizeMs), () {
        if (!mounted) return;
        setState(() => _phase = _GamePhase.recall);
      });
    });
  }

  /// Daraja → (grid, target count)
  (int, int) _configFor(int level) {
    if (level <= 2) return (3, 3 + level);    // 3x3: 4, 5
    if (level <= 5) return (4, 4 + level);    // 4x4: 7, 8, 9
    if (level <= 8) return (5, 6 + level - 5); // 5x5: 7, 8, 9
    return (6, 9 + (level - 8).clamp(0, 9));   // 6x6+
  }

  Set<int> _randomCells(int total, int count) {
    final rng = Random();
    final all = List.generate(total, (i) => i)..shuffle(rng);
    return all.take(count).toSet();
  }

  void _onTap(int index) {
    if (_phase != _GamePhase.recall) return;
    if (_selected.contains(index)) return;

    setState(() {
      _selected.add(index);
    });

    if (_target.contains(index)) {
      // To'g'ri
      if (_selected.length >= _targetCount &&
          _selected.intersection(_target).length == _targetCount) {
        _winLevel();
      }
    } else {
      // Xato
      _loseLevel();
    }
  }

  void _winLevel() {
    setState(() {
      _phase = _GamePhase.correct;
      _score += _targetCount * 10;
    });
    Future.delayed(const Duration(milliseconds: 1200), () {
      if (!mounted) return;
      _level++;
      _startLevel();
    });
  }

  void _loseLevel() {
    setState(() {
      _phase = _GamePhase.wrong;
      _lives--;
    });
    Future.delayed(const Duration(milliseconds: 1200), () {
      if (!mounted) return;
      if (_lives <= 0) {
        _finish();
      } else {
        _startLevel();
      }
    });
  }

  Future<void> _finish() async {
    setState(() => _phase = _GamePhase.finished);
    final state = context.read<AppState>();
    await state.incrementSessions();
    await state.addCoins((_score / 5).round().clamp(1, 100));
  }

  void _restart() {
    setState(() {
      _level = 1;
      _score = 0;
      _lives = 3;
      _selected = {};
    });
    _startLevel();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        title: const Text('Xotira matritsasi'),
      ),
      body: Container(
        decoration: const BoxDecoration(gradient: AppColors.cosmicGradient),
        child: SafeArea(
          child: Column(
            children: [
              _topBar(),
              const SizedBox(height: 16),
              _phaseLabel(),
              const SizedBox(height: 16),
              Expanded(child: Center(child: _buildGrid())),
              if (_phase == _GamePhase.finished) _resultCard(),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  Widget _topBar() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.cosmicMid,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        children: [
          _stat('Daraja', '$_level', AppColors.neuronGreen),
          const Spacer(),
          _stat('Ball', '$_score', AppColors.plasmaYellow),
          const Spacer(),
          _stat('Hayot', '❤️ ' * _lives, AppColors.accentRed, large: false),
        ],
      ),
    );
  }

  Widget _stat(String label, String value, Color color, {bool large = true}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            fontSize: 11,
            color: AppColors.cosmicLight,
            fontWeight: FontWeight.w600,
            letterSpacing: 0.5,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          value,
          style: TextStyle(
            fontSize: large ? 22 : 14,
            fontWeight: FontWeight.w600,
            color: color,
          ),
        ),
      ],
    );
  }

  Widget _phaseLabel() {
    String text;
    Color color;
    switch (_phase) {
      case _GamePhase.ready:
        text = 'Tayyor bo\'ling...';
        color = AppColors.cosmicLight;
        break;
      case _GamePhase.memorize:
        text = 'Eslab qoling';
        color = AppColors.plasmaYellow;
        break;
      case _GamePhase.recall:
        text = 'Endi takrorlang';
        color = AppColors.neuronGreen;
        break;
      case _GamePhase.correct:
        text = 'A\'lo!';
        color = AppColors.neuronGreen;
        break;
      case _GamePhase.wrong:
        text = 'Eslamadingiz';
        color = AppColors.accentRed;
        break;
      case _GamePhase.finished:
        text = 'O\'yin tugadi';
        color = AppColors.boboWarmth;
        break;
    }
    return Text(
      text,
      style: TextStyle(
        fontSize: 18,
        fontWeight: FontWeight.w600,
        color: color,
      ),
    );
  }

  Widget _buildGrid() {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: AspectRatio(
        aspectRatio: 1,
        child: GridView.builder(
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: _gridSize,
            crossAxisSpacing: 8,
            mainAxisSpacing: 8,
          ),
          itemCount: _gridSize * _gridSize,
          itemBuilder: (_, i) => _buildCell(i),
        ),
      ),
    );
  }

  Widget _buildCell(int index) {
    final isTarget = _target.contains(index);
    final isSelected = _selected.contains(index);

    Color bg;
    Widget? icon;

    switch (_phase) {
      case _GamePhase.memorize:
        // Naqshni ko'rsatish
        bg = isTarget
            ? AppColors.boboWarmth.withValues(alpha: 0.55)
            : AppColors.cosmicMid;
        if (isTarget) {
          icon = const Icon(Icons.star_rounded, color: AppColors.pureWhite, size: 24);
        }
        break;
      case _GamePhase.recall:
        if (isSelected && isTarget) {
          bg = AppColors.neuronGreen.withValues(alpha: 0.5);
          icon = const Icon(Icons.check_rounded, color: AppColors.pureWhite, size: 22);
        } else if (isSelected && !isTarget) {
          bg = AppColors.accentRed.withValues(alpha: 0.5);
          icon = const Icon(Icons.close_rounded, color: AppColors.pureWhite, size: 22);
        } else {
          bg = AppColors.cosmicMid;
        }
        break;
      case _GamePhase.correct:
        bg = isTarget
            ? AppColors.neuronGreen.withValues(alpha: 0.5)
            : AppColors.cosmicMid;
        if (isTarget) {
          icon = const Icon(Icons.check_rounded, color: AppColors.pureWhite, size: 22);
        }
        break;
      case _GamePhase.wrong:
        if (isTarget) {
          bg = AppColors.boboWarmth.withValues(alpha: 0.4);
          icon = const Icon(Icons.star_rounded, color: AppColors.pureWhite, size: 22);
        } else if (isSelected) {
          bg = AppColors.accentRed.withValues(alpha: 0.5);
          icon = const Icon(Icons.close_rounded, color: AppColors.pureWhite, size: 22);
        } else {
          bg = AppColors.cosmicMid;
        }
        break;
      default:
        bg = AppColors.cosmicMid;
    }

    return GestureDetector(
      onTap: () => _onTap(index),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: AppColors.cosmicLight.withValues(alpha: 0.15),
          ),
        ),
        child: Center(child: icon ?? const SizedBox.shrink()),
      ),
    );
  }

  Widget _resultCard() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: AppColors.cosmicMid,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: AppColors.boboWarmth.withValues(alpha: 0.3)),
      ),
      child: Column(
        children: [
          const Text('🧠', style: TextStyle(fontSize: 48)),
          const SizedBox(height: 8),
          const Text(
            'Yaxshi mashq!',
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.w600,
              color: AppColors.pureWhite,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            'Daraja $_level · $_score ball',
            style: const TextStyle(
              color: AppColors.pureWhite,
              fontSize: 14,
            ),
          ),
          const SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ElevatedButton(
                onPressed: _restart,
                child: const Text('Yana o\'ynash'),
              ),
              const SizedBox(width: 12),
              OutlinedButton(
                onPressed: () => Navigator.of(context).pop(),
                style: OutlinedButton.styleFrom(
                  foregroundColor: AppColors.pureWhite,
                  side: const BorderSide(color: AppColors.cosmicLight),
                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                ),
                child: const Text('Chiqish'),
              ),
            ],
          ),
        ],
      ),
    ).animate().fadeIn().slideY(begin: 0.3);
  }
}
