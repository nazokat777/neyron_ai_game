import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../theme/app_colors.dart';

/// Maryam — Bobo Aqlning yosh shogirdi
/// Foydalanuvchining yo'ldoshi va miya o'sishining ramzi
/// Streak va sessiyalar bilan kattalashadi, yorqinlashadi
class MaryamWidget extends StatelessWidget {
  final double size;
  final int level; // 1-100

  const MaryamWidget({
    super.key,
    this.size = 120,
    this.level = 1,
  });

  @override
  Widget build(BuildContext context) {
    final intensity = (level / 100).clamp(0.3, 1.0);

    return SizedBox(
      width: size,
      height: size,
      child: Stack(
        alignment: Alignment.center,
        children: [
          // Tashqi nur halosi — Maryam aurasi
          Container(
            width: size,
            height: size,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(
                colors: [
                  AppColors.boboWarmth.withValues(alpha: 0.3 * intensity),
                  AppColors.boboWarmth.withValues(alpha: 0.0),
                ],
              ),
            ),
          ).animate(onPlay: (c) => c.repeat()).scale(
                begin: const Offset(0.95, 0.95),
                end: const Offset(1.05, 1.05),
                duration: 3.seconds,
                curve: Curves.easeInOut,
              ),

          // Atrofda uchayotgan fikr-uchqunlari (neyron-zarralar)
          ..._buildSparkles(intensity),

          // Maryam avatari — markazda
          Container(
            width: size * 0.75,
            height: size * 0.75,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const RadialGradient(
                colors: [
                  Color(0xFFFFE5D9), // iliq och pushti
                  Color(0xFFE8A87C), // bobo iliq rang
                  Color(0xFF8B5A3C), // chuqurroq
                ],
                stops: [0.0, 0.6, 1.0],
              ),
              boxShadow: [
                BoxShadow(
                  color: AppColors.boboWarmth.withValues(alpha: 0.5 * intensity),
                  blurRadius: 20 * intensity,
                  spreadRadius: 2 * intensity,
                ),
              ],
            ),
            child: Stack(
              alignment: Alignment.center,
              children: [
                // Yuz emoji — keyinroq haqiqiy rasm bilan almashtiriladi
                Text(
                  '👧',
                  style: TextStyle(fontSize: size * 0.45),
                ),
                // Boshidagi gul
                Positioned(
                  top: size * 0.06,
                  right: size * 0.18,
                  child: Text(
                    '🌸',
                    style: TextStyle(fontSize: size * 0.16),
                  ).animate(onPlay: (c) => c.repeat(reverse: true)).rotate(
                        begin: -0.05,
                        end: 0.05,
                        duration: 2.seconds,
                        curve: Curves.easeInOut,
                      ),
                ),
              ],
            ),
          ).animate(onPlay: (c) => c.repeat(reverse: true)).scale(
                begin: const Offset(1, 1),
                end: const Offset(1.02, 1.02),
                duration: 2.5.seconds,
                curve: Curves.easeInOut,
              ),
        ],
      ),
    );
  }

  List<Widget> _buildSparkles(double intensity) {
    final count = (5 + (intensity * 5)).round();
    final sparkles = <Widget>[];
    final rng = Random(maryamSeed);

    for (int i = 0; i < count; i++) {
      final angle = (2 * pi * i) / count + rng.nextDouble() * 0.5;
      final distance = size * (0.42 + rng.nextDouble() * 0.06);
      final x = distance * cos(angle);
      final y = distance * sin(angle);
      final sparkleSize = 4.0 + rng.nextDouble() * 3;

      sparkles.add(
        Positioned(
          left: size / 2 + x - sparkleSize / 2,
          top: size / 2 + y - sparkleSize / 2,
          child: Container(
            width: sparkleSize,
            height: sparkleSize,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: AppColors.plasmaYellow.withValues(alpha: 0.85),
              boxShadow: [
                BoxShadow(
                  color: AppColors.plasmaYellow.withValues(alpha: 0.6),
                  blurRadius: 5,
                ),
              ],
            ),
          )
              .animate(
                onPlay: (c) => c.repeat(reverse: true),
                delay: (rng.nextInt(1500)).milliseconds,
              )
              .fadeIn(duration: 1.seconds)
              .then()
              .fadeOut(duration: 1.seconds),
        ),
      );
    }
    return sparkles;
  }

  static const int maryamSeed = 7;
}
