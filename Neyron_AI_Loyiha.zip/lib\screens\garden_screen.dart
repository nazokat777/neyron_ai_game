import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../theme/app_colors.dart';

/// "Maxsus Bog'lar" — qo'shimcha qo'llab-quvvatlash modullari
/// Tibbiy emas, qo'llab-quvvatlovchi makonlar
class GardenScreen extends StatelessWidget {
  const GardenScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(gradient: AppColors.cosmicGradient),
      child: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Maxsus Bog\'lar',
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.w700,
                  color: AppColors.pureWhite,
                ),
              ).animate().fadeIn(),
              const SizedBox(height: 4),
              const Text(
                'Tinch va parvarishli makonlar',
                style: TextStyle(color: AppColors.pureWhite, fontSize: 14),
              ),
              const SizedBox(height: 24),
              _gardenCard(
                emoji: '🌳',
                title: 'Xotira Bog\'i',
                subtitle: 'Yumshoq xotira mashqlari',
                description: 'Kunlik xotiralarni saqlash, yuzlar va joylar bilan ishlash.',
                accent: AppColors.neuronGreen,
              ),
              const SizedBox(height: 12),
              _gardenCard(
                emoji: '🌙',
                title: 'Sokin Burchak',
                subtitle: 'Tinch va xavfsiz makon',
                description: 'Ortiqcha stimullarsiz, ranglar va shakllar bilan tinch o\'yinlar.',
                accent: AppColors.uchqunGlow,
              ),
              const SizedBox(height: 12),
              _gardenCard(
                emoji: '🌸',
                title: 'Mehr Bog\'i',
                subtitle: 'Hissiyot va kommunikatsiya',
                description: 'Yuz ifodalari, suhbat ko\'nikmalari va emotsional bog\'lanish.',
                accent: AppColors.boboWarmth,
              ),
              const SizedBox(height: 24),
              _disclaimerCard(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _gardenCard({
    required String emoji,
    required String title,
    required String subtitle,
    required String description,
    required Color accent,
  }) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.cosmicMid,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: accent.withValues(alpha: 0.28)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 56,
                height: 56,
                decoration: BoxDecoration(
                  color: accent.withValues(alpha: 0.14),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Center(child: Text(emoji, style: const TextStyle(fontSize: 30))),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.w600,
                        color: AppColors.pureWhite,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      subtitle,
                      style: TextStyle(
                        fontSize: 12,
                        color: accent,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: AppColors.cosmicLight.withValues(alpha: 0.2),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Text(
                  'Tez orada',
                  style: TextStyle(
                    fontSize: 10,
                    color: AppColors.cosmicLight,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            description,
            style: const TextStyle(
              fontSize: 13,
              color: AppColors.pureWhite,
              height: 1.5,
            ),
          ),
        ],
      ),
    ).animate().fadeIn(duration: 400.ms).slideX(begin: 0.04);
  }

  Widget _disclaimerCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.cosmicMid,
        borderRadius: BorderRadius.circular(18),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: AppColors.boboWarmth.withValues(alpha: 0.15),
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Icon(Icons.info_outline_rounded,
                color: AppColors.boboWarmth, size: 18),
          ),
          const SizedBox(width: 12),
          const Expanded(
            child: Text(
              'Bu bog\'lar tibbiy davo emas — qo\'llab-quvvatlovchi mashqlar. Tibbiy maslahat uchun shifokorga murojaat qiling.',
              style: TextStyle(
                fontSize: 12,
                color: AppColors.pureWhite,
                height: 1.5,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
